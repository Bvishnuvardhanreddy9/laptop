package methodoverloadandoverridding;
	public class add {
		public static void add(int a,int b) {
			System.out.println(a+b);
		}
		public static void add(float a,float b) {
			System.out.println(a+b);
		}
		public static void add(double a,double b) {
			System.out.println(a+b);
		}
		public static void main(String[] args) {
			add(10,20);
			add(12.0,13.0);
			add(78.00,89.00);
		}
		
}
