package methodoverloadandoverridding;

public class mor2 extends methodoverriding{
	public void whatsappversions() {
		System.out.println("version 2->single ticks+double ticks+blue ticks");
	}
public static void main(String[] args) {
	mor2 a=new mor2 ();
		a.whatsappversions();
	}

}
