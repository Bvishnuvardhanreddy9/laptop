package methodoverloadandoverridding;

public class methodoverriding {
	public void whatsappversions() {
		System.out.println("version 1->only single ticks");
	}
public static void main(String[] args) {
	methodoverriding a=new methodoverriding();
		a.whatsappversions();
	}

}
