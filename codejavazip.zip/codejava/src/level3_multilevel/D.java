package level3_multilevel;

public interface D extends C {
	void D();

}
