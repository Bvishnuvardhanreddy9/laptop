package level3_multilevel;

public class Final implements D{
	public void C() {
		System.out.println("c");
	}
	public void D() {
		System.out.println("d");
	}
	public void E() {
		System.out.println("e");
	}
	public static void main(String[] args) {
		Final f=new Final();
		f.C();
		f.D();
		f.E();
	}
}
