package level3_multilevel;

public  interface C {
	void C();
}



