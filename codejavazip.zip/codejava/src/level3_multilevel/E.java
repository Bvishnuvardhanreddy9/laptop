package level3_multilevel;

public interface E extends D{
void E();

}
