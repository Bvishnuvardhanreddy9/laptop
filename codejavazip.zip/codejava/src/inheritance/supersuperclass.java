package inheritance;

public class supersuperclass {
	int a;
	int b;
	int c;
	public void display() {
	}
	
		public static void main(String[] args) {
			singlesuperclass ssc=new singlesuperclass();
			ssc.a=10;
			ssc.b=20;
			ssc.display();
		}
	
	}	


