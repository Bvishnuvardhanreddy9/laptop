package inheritance;

public class singlesubclass extends singlesuperclass {
	public static void main(String[] args) {
	singlesubclass ssc=new singlesubclass();
	ssc.a=10;
	ssc.b=20;
	ssc.display();
	int c=56;
	System.out.println(c);
	}


}
