package inheritance;

public class hirsub2 extends hirsuper {
	public void car2() {
		System.out.println("BMW M7");
	}
	public static void main(String[] args) {
		hirsub2  hs2=new hirsub2();
		hs2.car();
		hs2.car2();
	}

}
