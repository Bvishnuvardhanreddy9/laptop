package inheritance;

public class hirsuper {
	public void car() {
		System.out.println("BMW M3");
	}
	public static void main(String[] args) {
		hirsuper h=new hirsuper();
		h.car();
	}

}
