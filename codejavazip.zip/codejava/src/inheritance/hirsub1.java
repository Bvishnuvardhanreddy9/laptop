package inheritance;

public class hirsub1 extends hirsuper{
	public void car1() {
		System.out.println("BMW M5");
	}
	public static void main(String[] args) {
		hirsub1 hs1=new hirsub1();
		hs1.car1();
		hs1.car();
	}

}
