package inheritance;

public class multisubsub extends multisub{
	public void car2() {
		System.out.println("BMW M5");
	}
	public static void main(String[] args) {
		multisubsub ms=new multisubsub();
		ms.car2();
		ms.car1();
		ms.car();
	}


}
