package program;

public class half_array {
	public static void half(int a[]) {
		for(int i=0;i<=(a.length-1)/2;i++) {
			System.out.println(a[i]);
		}
	}
	public static void main(String[] args) {
		int a[]= {1,2,3,4,5,6};
		half(a);
	}
}
