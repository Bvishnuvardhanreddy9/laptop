package program;

public class Sum_FIrst_Last {
	public static void sum(int a[]) {
		System.out.println(a[0]+a[a.length-1]);
	}
	public static void main(String[] args) {
		int a[]= {1,2,3,};
		sum(a);
	}

}
 