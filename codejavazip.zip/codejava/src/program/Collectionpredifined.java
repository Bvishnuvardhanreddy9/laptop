package program;
import java.util.ArrayList;
public class Collectionpredifined {
	public static void main(String[] args) {
		ArrayList <Object> a=new ArrayList();
	a.add(1);
	a.add(2);
	a.add(3);
	a.add(100);
	a.add(98);
	a.add(99);
	a.add(2,50);
	System.out.println("Element at index 2:"+a.get(2));
	a.set(2,55);
	System.out.println("Afetr set at index 2:"+a);
	a.remove(3);
	System.out.println("After remove index 3:"+a);
	System.out.println("contains 99?"+a.contains(99));
	System.out.println("index of 99:"+a.indexOf(99));
	a.add(99);
	System.out.println("Last index of 99:"+a.lastIndexOf(99));
	System.out.println("siz:e"+a.size());
	System.out.println("is Empty"+a.isEmpty());
	System.out.println("sublist 1 to 4"+a.subList(1,4));
	a.clear();
	System.out.println("After clear:"+a);
	}

}
