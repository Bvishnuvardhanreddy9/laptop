package program;

public class toUpperCase_method {
	public static void main(String[] args) {
		String s="  vishnu";
		String s2=s.toUpperCase();
		System.out.println(s2);
		
		}


}
