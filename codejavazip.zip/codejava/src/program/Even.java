package program;

public class Even {
	public static void main(String[] args) {
		int a[]= {1,3,5,7,6,2,4};
		for(int i=0;i<=a.length-1;i++) {
			if(a[i]%2==0) {
				System.out.println("Even elments"+a[i]);
			}
		}
	}

}
