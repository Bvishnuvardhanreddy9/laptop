package program;

public class toLowerCase {
	String s="  vishnu";
	String s3=s.toLowerCase();
	
	}

