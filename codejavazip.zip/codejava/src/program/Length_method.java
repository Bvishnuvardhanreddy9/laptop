package program;

public class Length_method {
		public static void main(String[] args) {
			String s="  hello";
			System.out.println(s.length());
			}
}

