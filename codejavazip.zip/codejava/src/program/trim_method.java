package program;

public class trim_method {
	public static void main(String[] args) {
	String s="  vishnu";
	String s2=s.trim();
	System.out.println(s2);
	
	}
}