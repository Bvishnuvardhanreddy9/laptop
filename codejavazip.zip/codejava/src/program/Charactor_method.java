package program;

public class Charactor_method {
	public static void main(String[] args) {
		String s="  hello";
		char a=s.charAt(3);
		System.out.println(s.length());
		}


}
