package Interface;

public class test implements sample {
	public void sample () {
		System.out.println("sample block");
	}
	public static void main(String[] args) {
		test t=new test();
		t.sample();
		t.sample1();
	}
	@Override
	public void sample1() {
	System.out.println("complete methods");
		
	}
	

}
