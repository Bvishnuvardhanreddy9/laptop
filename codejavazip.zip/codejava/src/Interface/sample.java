package Interface;

public interface sample {
	void sample1();

}
