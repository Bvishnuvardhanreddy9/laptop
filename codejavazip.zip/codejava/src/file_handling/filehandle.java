package file_handling;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

public class filehandle {
	public static void main(String[] args) {
		File f=new File("hii.txt");
		try {
			boolean res=f.createNewFile();
			System.out.println(res);
			System.out.println(f.getAbsolutePath());
		}
		catch(Exception e) {
			System.out.println("its not true");
		}
		try {
			FileWriter fw=new FileWriter(f);
	        fw.write("hello");
	        fw.flush();
	        fw.close();
	        System.out.println("content is share to file");
	        }
		catch(Exception e) {
			System.out.println("connt write");
		}
		try {
			FileReader fr=new FileReader(f);
			for(int i=0;i<f.length();i++) {
				System.out.println((char) fr.read());
				}
			}
			catch(Exception e) {
				System.out.println("cannot read");
			}
	}

}
