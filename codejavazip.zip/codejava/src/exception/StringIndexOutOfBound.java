package exception;

public class StringIndexOutOfBound {
	public static void main(String[] args) {
		String s="hello";
		try {
			char ss=s.charAt(9);
			System.out.println(ss);
		}
		catch(Exception e) {
			System.out.println("its not find");
		}
	}

}
