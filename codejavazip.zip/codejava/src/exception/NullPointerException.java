package exception;

public class NullPointerException {
	public static void main(String[] args) {
		String hi=null;
		try {
			System.out.println(hi.length());
		}
		catch(Exception e) {
			System.out.println("its is null");
		}
	}

}
