package Searching;

public class Binarysearch {
	public static void main(String[] args) {
		int[] arr= {2,4,5,6,7};
		int target=5;
		int low=0;
		int mid;
	    int high=arr.length-1;
		boolean found=false;
		while(low<=high) {
		  mid=(low+high)/2;
			if(arr[mid]==target) {
			System.out.println("Found at index:"+mid);
			found=true;
			break;
		}
			else if(arr[mid]<target){
         low =mid+1;
     } 
		 else  {
         high=mid-1; 
     }
			if(!found) {
     System.out.println("Not found");
}
	}
	}
}