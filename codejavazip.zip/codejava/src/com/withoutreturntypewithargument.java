package com;

public class withoutreturntypewithargument {
	public static void Sub(int a,int b) {
		int result=a-b;
		System.out.println(result);
	}
	public static void main(String[] arg) {
		Sub(8,5);
	}

}
