package com;

public class Student1 {
    String uniform = "blue";
    int idcard = 123;
    String dept = "ECE";
    String section = "d";

    static String collegeName = "AITS"; 
    static int studentCount = 0;

    public Student1() { 
        studentCount++;
    }
    public void study() {
        System.out.println(uniform + " uniform student with ID " + idcard + " is studying in " + dept + " department, section " + section + " at " + collegeName); // Accesses both instance and static variables
    }
    public void printDetails() {
        System.out.println("--- Student Details ---");
        System.out.println("Uniform: " + uniform);
        System.out.println("ID Card: " + idcard);
        System.out.println("Department: " + dept);
        System.out.println("Section: " + section);
        System.out.println("College: " + collegeName); 
    }

    public static void displayStudentCount() {
        System.out.println("Total number of students: " + studentCount);
    }

    public static void main(String[] arg) {
        Student1 s1 = new Student1(); 
        s1.idcard = 101;
        s1.study(); 
        s1.printDetails();

        Student1 s2 = new Student1(); 
        s2.idcard = 102; 
        s2.study();
        s2.printDetails();

        Student1.displayStudentCount(); 
    }
}

