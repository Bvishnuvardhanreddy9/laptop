package com;

public class turnary {
	public static void main(String[] arg) {
		int a=10;
		int b=20;
		String result=a<b?"yes":"No";
		System.out.println(result);
	}

}
