package com;

public class local_and_global_variables {
	static int a=20;
	public static void main(String[] arg) {
		//inta=20
		System.out.println(a);
		
		
	}
	

}
