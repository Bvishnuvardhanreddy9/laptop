package com;

public class demo {
	public static void main(String[] arg) {
		System.out.println("hi guys");
	}
}
