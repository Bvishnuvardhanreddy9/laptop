package com;

public class primenumber {
	public static void main(String[] arg) {
		int b=5;
		int c=0;
		for(int i=1;i<=b;i++) {
			if(b%i==0) {
				c=c+1;
			}
		}
		if(c==2) {
			System.out.println("prime"+b);
		}
		else {
			System.out.println("notprime"+b);
		}
	}

}
	