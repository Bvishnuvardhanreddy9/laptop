package com;

public class withreturntypewithargument {
	public static int mul(int a,int b) {
		return a*b;
	}
	public static void main(String[] arg) {
		int result=mul(3,6);
		System.out.println(result);
	}

}
