package com;
import java.util.Scanner;
public class textscanner {
	public static void main(String[] arg) {
		System.out.print("enetr an integer:");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		System.out.print(a);
	}

}
