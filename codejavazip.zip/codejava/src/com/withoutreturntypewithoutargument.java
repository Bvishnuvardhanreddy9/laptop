package com;

public class withoutreturntypewithoutargument  {
	public static void add(int a,int b) {
		int result=a+b;
		System.out.println(result);
	}
	public static void main(String[] arg) {
		add(8,5);
	}

}


