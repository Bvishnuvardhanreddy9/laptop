package com;

public class explict {
	public static void main(String[] arg) {
		float f=10.01f;
		short s=(short)f;
		System.out.print(s);
	}
	

}
