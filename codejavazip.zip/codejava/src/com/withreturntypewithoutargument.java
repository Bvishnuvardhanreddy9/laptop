package com;

public class withreturntypewithoutargument {
	public static float div() {
		float a=100;float b=10;
		float result=a/b;
		return result;}
		public static void main(String[]args) {
			float hy=div();
			System.out.println(hy);
		}
	}


