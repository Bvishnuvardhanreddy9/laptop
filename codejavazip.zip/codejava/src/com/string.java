package com;
import java.util.Scanner;
public class string{
	public static void main(String[] arg) {
		Scanner Sc=new Scanner(System.in);
		System.out.println("enter a string");
		String a=Sc.next();
		System.out.println(a);
	}
	

	

}
