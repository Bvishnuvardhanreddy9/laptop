package com;

public class student {
    String uniform = "blue";
    int idcard = 123;
    String dept = "ECE";
    String section = "d";
    String clg = "AITS";

    public void study() {
        System.out.println("Student is studying");
    }

    // Method to print student details
    public void printDetails() {
        System.out.println("--- Student Details ---");
        System.out.println("Uniform: " + uniform);
        System.out.println("ID Card: " + idcard);
        System.out.println("Department: " + dept);
        System.out.println("Section: " + section);
        System.out.println("College: " + clg);
    }

    public static void main(String[] arg) {
        student s1 = new student();
        s1.study(); 
        s1.printDetails(); // Call the custom method to print details
    }
}
