package com;

public class implict {
	public static void main(String[] arg) {
		short s=20;
		int a=s;
		System.out.println(a);
		
	}

}
