package com;

import java.util.Scanner;

public class factors {
	public static void main(String[] arg) {
		int i;
		Scanner Sc=new Scanner(System.in);
		System.out.println("enter a number for factorial");
		int a=Sc.nextInt();
		System.out.println("the factor of the number is");
		for(i=1;i<=a;i++) {
			if (a%i==0) {
				System.out.println(i);
			}
		}
		
	}

}
