package com;

public class Classsandobject {
	static String compony_name="tcs";
	static String company_location="hyd";
	String emp_name;
	int emp_id;
	int emp_salary;
	public static void developer(){
		System.out.println("designation is devoloper");
	}
	public void tester() {
		System.out.println("designation is tester");
	}
	public static void main(String[] args) {
		System.out.println(compony_name);
		System.out.println(company_location);
		Classsandobject co=new Classsandobject();
		co.emp_name="Ram";
		System.out.println(co.emp_name);
		co.emp_id=123;
		System.out.println(co.emp_id);
		co.emp_salary=25000;
		System.out.println(co.emp_salary);
		developer();
		System.out.println("----------");
		Classsandobject co1=new Classsandobject();
		System.out.println(compony_name);
		System.out.println(company_location);
		co1.emp_name="sita";
		System.out.println(co1.emp_name);
		co1.emp_id=234;
		System.out.println(co1.emp_id);
		co1.emp_salary=100000;
		System.out.println(co1.emp_salary);
	    co1.tester();
		  
		   }
		
	}
	


