package com;

public class greatestnumber {
	public static void main(String[] arg) {
		int a=10;
		int b=20;
		int c=30;
		if (a>=b && a>=c) {
			System.out.println("smallest number is"+a);
		}
		else if(b>=a && b>=c) {
			System.out.println("smallest number is"+b);
		}
		else {
			System.out.println("smallest number is"+c);
		}
	}

}
