package com;

import java.security.DrbgParameters.NextBytes;
import java.util.Scanner;

public class switch_case {
	public static void main(String[] arg) {
		System.out.println("enter a character");
		Scanner ch=new Scanner(System.in);
		 char A=ch.next().charAt(0);
		switch(A) {
		}
	}

}
