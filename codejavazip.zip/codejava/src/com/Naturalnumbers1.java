package com;

public class Naturalnumbers1{
public static void main(String[]arg) {
			int i;
			System.out.println("1 to 1000 prime numbers");
			for(i=1;i<=1000;i++) {
				System.out.println(i);
			}
		}
	}



