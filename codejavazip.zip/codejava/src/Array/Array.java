package Array;
public class Array {
		public static void main(String[] args) {
			String []arr=new String[10];
			arr[0]="apple";
			arr[1]="guava";
			arr[3]="banana";
			arr[5]="mango";
			arr[9]="orange";
			for(int i=0;i<=arr.length-1;i++) {
				System.out.println(arr[i]);
			}
			
		}

	}


