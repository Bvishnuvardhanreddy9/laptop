package Array;

public class Arraya {
	public static void main(String[] args) {
		int []arr=new int[10];
		arr[0]=1;
		arr[1]=32;
		arr[3]=53;
		arr[5]=35;
		arr[9]=3;
		System.out.println(arr[6]);
		System.out.println("--------");
		for(int i=arr.length-1;i>-1;i--) {
			System.out.println(arr[i]);
		}
		
	}

}
