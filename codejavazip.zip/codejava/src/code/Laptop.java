package code;

public class Laptop {
	private String name;
	private String model;
	private String memory;
	private int ram;
	private int cost;
	public Laptop() {
		
	}
	public Laptop( String name,String model,String memory,int ram,int cost) {
	this.name=name;
	this.model=model;
	this.memory=memory;
	this.ram=ram;
	this.cost=cost;
}
	public void setname(String name) {
		this.name=name;
	}
	public String Getname() {
		return name;
	}
	public void setmodel(String model) {
		this.model=model;
	}
	public String Getmodel() {
		return model;
	}
	public void setmemory(String memory) {
		this.memory=memory;
	}
	public String Getmemory() {
		return memory;
	}
	public void setram(int ram) {
		this.ram=ram;
	}
	public int Getram() {
		return ram;
	}
	public void setcost(int cost) {
		this.cost=cost;
	}
	public int Getcost() {
		return cost;
	}
	public void display() {
		System.out.println("name of the laptop:"+Getname());
		System.out.println("model of the laptop:"+Getmodel());
		System.out.println("memory of the laptop:"+Getmemory());
		System.out.println("ram of the laptop:"+Getram());
		System.out.println("cost of the laptop:"+Getcost());
	}
	public static void main(String[] args) {
		System.out.println("laptop details");
		System.out.println("asus");
		System.out.println("123");
		System.out.println("40000");
		System.out.println("vishnu");
		
		
	}


}