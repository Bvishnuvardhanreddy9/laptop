import java.util.Scanner;
package javaprograms;

public class Oops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int b[];
b=new int[5];
int [] c =new int[5];
Scanner sc=new Scanner(System.in) ;
for(int i=0;i<5;i++) {
	System.out.println("enter the number:");
	c[1]=in.nextInt();
}
for (int element:c) {
	System.out.println(element);
}
	}

}
