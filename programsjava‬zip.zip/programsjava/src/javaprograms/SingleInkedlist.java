package javaprograms;

public class SingleInkedlist {
	public static void traversallist(Node1 head) {
		while(head!=null) {
			System.out.println(head.data+"");
			head=head.next;
		}
		System.out.println();
	}
	public static void main(String[] args) {
		Node1 head=new Node1(10);
		head.next=new Node1(20);
		head.next.next=new Node1(30);
		head.next.next.next=new Node1(40);
		traversallist(head);
	}

}
