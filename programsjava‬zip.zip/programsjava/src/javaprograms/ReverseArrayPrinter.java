package javaprograms;

public class ReverseArrayPrinter {
	 public static void main(String[] args) {
	        int[] num = {2,3,5,7,9}; 

	        System.out.print("Original array:");
	        for (int i = 0;i<num.length;i++) {
	            System.out.print(num[i]);
	        }
	        System.out.print("Array in reverse order:");
	        for (int i=num.length-1;i>=0;i--) {
	            System.out.print(num[i]);
	        }
	        System.out.println();
	    }
}
