package javaprograms;
import java.util.HashMap;
public class Hashmapexample {
	public static void main(String[] args) {
		HashMap<Integer,String>map=new HashMap<>();
		map.put(1, "APPLE");
		map.put(2,"BANANA");
		map.put(3, "CHERRY");
		map.put(2,"MANGO");
		System.out.println(map.get(1));
		System.out.println(map.get(2));
		System.out.println(map.containsKey(3));
		System.out.println(map.containsValue("CHERRY"));
	}
	

}
