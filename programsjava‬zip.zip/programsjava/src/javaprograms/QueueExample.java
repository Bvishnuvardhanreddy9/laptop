package javaprograms;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
	public static void main(String[] args) {
	Queue<Integer>Queue=new LinkedList<>();
	Queue.add(10);
	Queue.add(20);
	Queue.add(30);
	System.out.println("Queue:"+Queue.peek());
	System.out.println("Removed"+Queue.remove());
	System.out.println("Queue after remove:"+Queue);
	System.out.println("polled:"+Queue.poll());
	System.out.println("Queue after polls:"+Queue);
	System.out.println("size:"+Queue.size());
	System.out.println("Is Queue empty:"+Queue.isEmpty());
	
	}

}
