package javaprograms;

public class VowelorNot {
	public static void main(String[] args) {
        char ch = 'l';
        ch = Character.toLowerCase(ch);

        if (ch == 'a' || ch =='e' || ch=='i' || ch=='o' || ch=='u') {
            System.out.println(ch +"is a vowel");
        } else if (Character.isLetter(ch)) { 
            System.out.println(ch +"is not a vowel");
        } 
    }
}

