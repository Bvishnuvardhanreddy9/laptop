package javaprograms;

public class doublylinkedlist {
	public static void forwardtraversal(Node head) {
		Node curr=head;
		while(curr!=null) {
			System.out.println(curr.data+"");
			curr=curr.next;
		}
		System.out.println();
	}
	public static void main(String[] args) {
		Node head=new Node(1);
		Node second=new Node(2);
		Node third=new Node(3);
		head.next=second;
		second.prev=head;
		second.next=third;
		second.prev=second;
		System.out.println("forward Traversal:");
		forwardtraversal(head);
	}

}
