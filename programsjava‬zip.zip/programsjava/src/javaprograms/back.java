package javaprograms;

 class Node2 {
	int data;
	Node2 next;
	Node2 prev;
	Node2 (int val){
		data=val;
		next=null;
		prev=null;
	}
}
public class back{

public static void backwardtraversal(Node2 tail) {
	Node2 curr=tail;
	while(curr!=null) {
		System.out.println(curr.data+"");
		curr=curr.prev;
	}
}
public static void main(String[] args) {
	Node2 head =new Node2(1);
	Node2 second =new Node2(2);
	Node2 third =new Node2(3);
	head.next=second;
	second.prev=head;
	third.prev=second;
	System.out.println("backwardtraversal:");
	backwardtraversal(third);
	
}}

