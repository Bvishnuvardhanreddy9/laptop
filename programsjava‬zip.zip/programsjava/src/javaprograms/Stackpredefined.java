package javaprograms;
import java.util.Stack;
public class Stackpredefined{
		public static void main(String[] args) {
			Stack<Integer>stack=new Stack<>();
			stack.push(7);
			stack.push(17);
			stack.push(18);
			System.out.println("stack:"+stack);
			System.out.println("Top element:"+stack.peek());
			System.out.println("Popped:"+stack.pop());
			System.out.println("stack after pop:"+stack);
			System.out.println("Position of 7:"+stack.search(7));
			System.out.println("Is stack empty?"+stack.isEmpty());
			System.out.println("Size:"+stack.size());
		}
	}



