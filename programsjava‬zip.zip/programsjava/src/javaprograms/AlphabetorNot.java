package javaprograms;
public class AlphabetorNot {
	 public static void main(String[] args) {
	        char ch ='H'; 
	        if ((ch>='a'&&ch<='z') || (ch >='A'&& ch <= 'Z')) {
	            System.out.println(ch+" is an alphabet.");
	        } else {
	            System.out.println(ch+"is not an alphabet.");
	        }
	    }
}
