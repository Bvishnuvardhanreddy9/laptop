package javaprograms;

public class Node1 {
	int data;
		Node1 next;
		Node1(int new_data){
			this.data=new_data;
			this.next=null;
		}
	}


