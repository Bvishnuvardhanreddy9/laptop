package javaprograms;
import java.util.ArrayList;
public class SmallestElement {
		public static void main(String[]args){
			int[] arr= {1,2,3,4,5,6};		  
		        int smallest =arr[0];
		        for (int i = 1; i <=arr.length-1; i++){
		            if (arr[i] != smallest){
		                System.out.println("Second smallest element is:"+arr[i]);
		                return;
		            }
		        }
		        System.out.println(arr);
}
}